"""本次实验专用入口：复用 logical-client，隔离四个 TP2 服务。"""
from __future__ import annotations

import argparse
import dataclasses
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import time
import urllib.request

BASE = Path('/ssd/1/wister.zwz/nan-guard')
REPO = BASE / 'repo'
OOT = REPO / 'pd_disagg/src/vllm-torchtpu'
PYTHON = BASE / 'venv/bin/python'
MODEL = BASE / 'models/Qwen3.5-35B-A3B-FP8'
SHIM = BASE / 'p4d4-source-nan-20261004/logical-client/libtpu-logical-client.so'
ROLES = {'p0': (0, 1), 'p1': (6, 7), 'd0': (2, 3), 'd1': (4, 5)}
PORTS = {'p0': 18400, 'p1': 18410, 'd0': 19400, 'd1': 19410}
CONTROLLERS = {'p0': 27000, 'p1': 27400, 'd0': 28000, 'd1': 28400}


def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def health(port):
    try:
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open(f'http://127.0.0.1:{port}/health', timeout=1) as response:
            return response.status
    except Exception as error:
        return repr(error)


def port_free(port):
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', port))


def helpers():
    sys.path.insert(0, str(REPO))
    from pd_disagg.experiments.libtpu_logical_client import manifest, probe, launch, paths
    return manifest, probe, launch, paths


def probe_worker(args):
    _, probe, _, _ = helpers()
    return probe.run_worker(args.root / 'manifest.json', args.role, args.rank,
                            ROLES[args.role][args.rank], args.root / 'probe/results', True)


def launch_service(args):
    manifest_module, _, launch, paths = helpers()
    role = args.role
    prefill = role.startswith('p')
    index = list(ROLES).index(role)
    os.environ.update({
        'PYTHONPATH': str(args.root / 'runtime/src') + ':' + str(args.root / 'runtime'),
        'TPU_LOCAL_RANK_OFFSET': '0',
        'TPU_KV_TRANSFER_NAMESPACE': args.root.name + '-' + role,
        'TPU_RAIDEN_JOB_NAME': 'prefill' if prefill else 'decode',
        'TPU_RAIDEN_ENGINE_ID': role + '-engine',
        'TPU_RAIDEN_RESHARD_IMPL': 'store',
        'TPU_RAIDEN_ADVERTISE_HOST': '127.0.0.1',
        'TPU_RAIDEN_RESHARD_PORT_BASE': str(CONTROLLERS[role]),
        'TPU_RAIDEN_STORE_DISPATCH_PORT_BASE': str(CONTROLLERS[role] + 100),
        'TPU_KV_TRANSFER_PORT': str(29100 + index * 100),
        'TPU_SIDE_CHANNEL_PORT': str(29600 + index * 10),
        'TPU_RAIDEN_PLAN_DUMP_DIR': str(args.root / 'plan_dump' / role),
    })
    compile_sizes = [2048] if prefill else [32, 64, 128]
    compilation = {
        'backend': 'vllm_torchtpu.compilation.tpu_compiler.TpuCompilerAdaptor',
        'compile_sizes': compile_sizes,
        'inductor_compile_config': {'enable_auto_functionalized_v2': False,
            'size_asserts': False, 'alignment_asserts': False, 'scalar_asserts': False},
    }
    kv = {'kv_connector': 'TPURaidenConnector',
          'kv_connector_module_path': 'vllm_torchtpu.distributed.kv_transfer.tpu_connector',
          'kv_role': 'kv_producer' if prefill else 'kv_consumer',
          'kv_port': 14579 + index * 10}
    argv = [str(PYTHON), '-m', 'vllm.entrypoints.openai.api_server',
        '--host', '127.0.0.1', '--port', str(PORTS[role]), '--model', str(MODEL),
        '--served-model-name', 'Qwen3.5-35B-A3B-FP8', '--trust-remote-code', '--seed', '42',
        '--max-model-len', '8192', '--max-num-seqs', '8',
        '--max-num-batched-tokens', '2048' if prefill else '128',
        '--enable-expert-parallel', '--disable-custom-all-reduce',
        '--gpu-memory-utilization', '0.90', '--kv-cache-dtype', 'fp8',
        '--language-model-only', '--no-disable-hybrid-kv-cache-manager',
        '--attention-backend', 'CUSTOM', '--mamba-cache-mode', 'align',
        '--prefix-cache-retention-interval', '0', '--enable-prompt-tokens-details',
        '--no-enable-log-requests', '--num-gpu-blocks-override', '128',
        '--enable-prefix-caching', '--async-scheduling',
        '--compilation-config', json.dumps(compilation),
        '--tensor-parallel-size', '2',
        '--prefill-context-parallel-size', '1',
        '--kv-transfer-config', json.dumps(kv),
        '--speculative-config', json.dumps({'method': 'mtp', 'num_speculative_tokens': 1 if prefill else 3}),
        '--block-size', '2304']
    write(args.root / (role + '-argv.json'), {'argv': argv, 'env': {
        key: value for key, value in os.environ.items()
        if key.startswith(('TPU_', 'LIBTPU_', 'VLLM_', 'TORCH_TPU_'))}})
    return launch.launch_role(args.root / 'manifest.json', role,
        paths.discover_real_libtpu(), SHIM, args.root / 'cache', argv)


def supervise(args):
    root = args.root
    root.mkdir(exist_ok=False, parents=True)
    for name in ('probe/logs', 'probe/results', 'logs', 'cache', 'plan_dump'):
        (root / name).mkdir(parents=True)
    manifest_module, probe, _, paths = helpers()
    ports = [*PORTS.values()]
    for index, role in enumerate(ROLES):
        ports += [CONTROLLERS[role] + delta for delta in (0, 1, 100, 101)]
        ports += [29100 + index * 100 + delta for delta in range(2)]
        ports += [29600 + index * 10, 14579 + index * 10]
    if len(ports) != len(set(ports)):
        raise ValueError('本实验各角色监听端口必须互不重叠')
    for port in ports:
        port_free(port)
    if sorted(rank for ranks in ROLES.values() for rank in ranks) != list(range(8)):
        raise ValueError('四个角色必须独占且完整覆盖八张 TPU')
    subprocess.run(['cp', '-a', str(OOT), str(root / 'runtime')], check=True)
    os.environ.update({
        'PYTHONPATH': str(root / 'runtime/src') + ':' + str(root / 'runtime'),
        'LD_LIBRARY_PATH': str(BASE / 'miniforge/lib'),
        'TMPDIR': str(root / 'cache'), 'XDG_CACHE_HOME': str(root / 'cache'),
        'HF_HOME': str(root / 'cache/huggingface'), 'VLLM_DO_NOT_TRACK': '1',
        'SRPC_STREAM_DISABLE_BAREX': '1', 'OMP_NUM_THREADS': '1',
        'TPU_SKIP_MDS_QUERY': 'true',
        'LIBTPU_INIT_ARGS': '--vbar_control_service_url=127.0.0.1:8353 --xla_tpu_enable_latency_hiding_scheduler=false --xla_tpu_scoped_vmem_limit_kib=65536',
        'JAX_PLATFORMS': 'tpu,cpu', 'PJRT_DEVICE': 'TPU', 'TPU_BACKEND_TYPE': 'jax',
        'XLA_PYTHON_CLIENT_PREALLOCATE': 'false', 'VLLM_ALLOW_LONG_MAX_MODEL_LEN': '1',
        'TPU_VLLM_ENABLE_UNIFIED_BLOCK_POOL': '1', 'TPU_USE_RAIDEN_KV_CACHE_MANAGER': '1',
        'TPU_RAIDEN_QWEN35_ADMISSION': '1', 'TPU_KV_RESHARD_TRANSPORT': 'raiden',
        'TPU_RAIDEN_TRANSFER_PARALLELISM': '2', 'TPU_RAIDEN_DST_SHARDS': '2',
        'TPU_RAIDEN_PREFIX_AWARE_LOAD': '1', 'TPU_P2P_WAIT_PULL_TIMEOUT': '120',
        'TPU_PREMAPPED_BUFFER_SIZE': '8589934592', 'TPU_PARALLEL_PRECOMPILE': '1',
        'TPU_KV_SHM_POOL_GB': '8', 'TPU_MAX_HOST_KV_BUFFER_SIZE': '64',
        'TPU_ENABLE_D2H_TRANSFER': '1', 'TPU_HMA_D2H_COPY_IMPL': 'device_put',
        'TPU_HMA_MIN_DONE_RECVING_BATCH': '1', 'TPU_HMA_MAX_DONE_RECVING_BATCH': '1',
        'TPU_HMA_MAX_INFLIGHT_D2H_SENDS': '1', 'TPU_HMA_MAX_INFLIGHT_PULLS': '8',
        'USE_MOE_SPARSE_CORE': '0', 'ONEHOT_MOE_PERMUTE_THRESHOLD': '1024',
        'TPU_RAGGED_GATHER_REDUCE_IMPL': 'fallback', 'TPU_RAGGED_GATHER_IMPL': 'fallback',
        'DP_SCHED_BATCH_PREFILL_MAX_ADMIT_PER_FLUSH': '0',
        'VLLM_SERVER_DEV_MODE': '1', 'VLLM_LOG_STATS_INTERVAL': '1',
        'MAMBA_SSM_CACHE_DTYPE': 'bfloat16', 'VLLM_KV_CACHE_LAYOUT': 'HND',
    })
    for key in ('TPU_ACCELERATOR_TYPE', 'TPU_WORKER_HOSTNAMES', 'TPU_WORKER_ID',
                'TPU_CHIPS_PER_HOST_BOUNDS', 'TPU_HOST_BOUNDS', 'TPU_TOPOLOGY',
                'TPU_TOPOLOGY_WRAP', 'TORCH_TPU_TIER3_COMPILATION_CACHE_ROOT'):
        os.environ.pop(key, None)
    initial = manifest_module.prepare_manifest()
    roles = tuple(manifest_module.Role(name, ranks,
                  f'tcp://127.0.0.1:{manifest_module._pick_unused_port()}')
                  for name, ranks in ROLES.items())
    manifest = dataclasses.replace(initial, roles=roles)
    manifest.write(root / 'manifest.json')
    versions = {name: importlib.metadata.version(name) for name in
                ('vllm', 'vllm-torchtpu', 'torch', 'torch-tpu', 'tpu-sync-torch', 'libtpu')}
    native = BASE / 'venv/lib64/python3.12/site-packages/tpu_sync/frameworks/torch/_tpu_raiden_torch_2_13_0.so'
    connector = root / 'runtime/src/vllm_torchtpu/distributed/kv_transfer/tpu_connector.py'
    write(root / 'config.json', {'host': socket.gethostname(), 'versions': versions,
        'native_sha256': hashlib.sha256(native.read_bytes()).hexdigest(),
        'connector_sha256': hashlib.sha256(connector.read_bytes()).hexdigest(),
        'shim_sha256': hashlib.sha256(SHIM.read_bytes()).hexdigest(),
        'source_snapshot': str(root / 'runtime'), 'model_path': str(MODEL),
        'roles': ROLES, 'ports': PORTS, 'controllers': CONTROLLERS,
        'process_owner': os.getuid(), 'environment': {
            key: value for key, value in os.environ.items()
            if key.startswith(('TPU_', 'LIBTPU_', 'VLLM_', 'TORCH_TPU_'))}})
    workers, handles = [], []
    try:
        for role, ranks in ROLES.items():
            for rank, physical in enumerate(ranks):
                log = (root / 'probe/logs' / f'{role}-{rank}.log').open('wb')
                handles.append(log)
                env = probe._worker_environment(manifest, role, rank, physical,
                                                paths.discover_real_libtpu(), SHIM)
                workers.append(subprocess.Popen([str(PYTHON), __file__, 'probe-worker',
                    '--root', str(root), '--role', role, '--rank', str(rank)],
                    env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True))
        deadline = time.monotonic() + 180
        while any(worker.poll() is None for worker in workers):
            if time.monotonic() >= deadline:
                raise TimeoutError('四个独立双卡客户端 collective probe 超过 180 秒')
            time.sleep(1)
        results = [json.loads(path.read_text()) for path in (root / 'probe/results').glob('*.json')]
        write(root / 'probe/summary.json', results)
        if len(results) != 8 or any('error' in value or value['world_size_env'] != 2
            or value['all_global_device_ids'] != [0, 1] or value['jax_device_ids'] != [0, 1]
            or value['global_device_id'] != value['logical_rank'] for value in results):
            raise RuntimeError('四角色双卡隔离 probe 未通过，不能启动模型')
        print('FOUR_ROLE_PROBE_OK', flush=True)
    finally:
        probe._terminate(workers)
        for log in handles:
            log.close()
    services = {}
    for role in ROLES:
        log = (root / 'logs' / (role + '.log')).open('wb')
        process = subprocess.Popen([str(PYTHON), __file__, 'service', '--root', str(root),
            '--role', role], env=os.environ.copy(), stdout=log, stderr=subprocess.STDOUT,
            start_new_session=True)
        log.close()
        services[role] = {'pid': process.pid, 'start_ticks': int(Path(f'/proc/{process.pid}/stat').read_text().split(')')[-1].split()[19])}
    write(root / 'services.json', services)
    (root / 'STARTED').write_text(str(time.time()))
    deadline = time.monotonic() + 1800
    while time.monotonic() < deadline:
        states = {role: health(port) for role, port in PORTS.items()}
        (root / 'heartbeat.txt').write_text(json.dumps({'ts': time.time(), 'phase': 'startup', 'health': states}))
        print(json.dumps({'phase': 'startup', 'ts': time.time(), 'health': states}), flush=True)
        if all(value == 200 for value in states.values()):
            (root / 'READY').write_text(str(time.time()))
            print('FOUR_SERVICES_READY', flush=True)
            return 0
        for role, record in services.items():
            path = Path(f'/proc/{record["pid"]}/stat')
            if not path.exists() or path.read_text().split(')')[-1].split()[0] == 'Z':
                raise RuntimeError(f'{role} 在启动期退出；检查 {root}/logs/{role}.log')
        time.sleep(10)
    raise TimeoutError('模型服务启动超过 1800 秒')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=('supervise', 'probe-worker', 'service'))
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--role', choices=tuple(ROLES))
    parser.add_argument('--rank', type=int)
    args = parser.parse_args()
    try:
        status = {'supervise': supervise, 'probe-worker': probe_worker, 'service': launch_service}[args.action](args)
    except BaseException as error:
        if args.action == 'supervise' and args.root.is_dir():
            (args.root / 'FAILED').write_text(repr(error))
        raise
    raise SystemExit(status)
