"""临时真实故障测试：精确杀 P0 worker，并观察两台 D 的三种流量。"""
from __future__ import annotations

import argparse
import concurrent.futures
import json
import math
import os
from pathlib import Path
import re
import signal
import socket
import statistics
import subprocess
import threading
import time
import urllib.error
import urllib.request
import uuid

from run_experiment import BASE, CONTROLLERS, MODEL, PORTS, health, write


def identity(pid):
    path = Path(f'/proc/{pid}')
    stat = (path / 'stat').read_text()
    fields = stat[stat.rfind(')') + 2:].split()
    return {'pid': pid, 'state': fields[0], 'ppid': int(fields[1]),
        'start_ticks': int(fields[19]), 'uid': path.stat().st_uid,
        'name': (path / 'cmdline').read_bytes().split(b'\0')[0].decode(errors='replace')}


def descendants(root, expected):
    current = identity(root)
    if current['start_ticks'] != expected or current['uid'] != os.getuid():
        raise ValueError(f'实验服务根进程代际或 UID 不符：{current}')
    rows = []
    for path in Path('/proc').iterdir():
        if path.name.isdigit():
            try:
                rows.append(identity(int(path.name)))
            except (OSError, ValueError):
                pass
    tree = {root: current}
    while True:
        children = [row for row in rows if row['ppid'] in tree and row['pid'] not in tree]
        if not children:
            break
        tree.update((row['pid'], row) for row in children)
    return list(tree.values())


class Case:
    def __init__(self, args):
        self.args = args
        self.root = args.root
        self.output = self.root / args.label
        self.output.mkdir(exist_ok=False)
        self.lock = threading.Lock()
        self.responses = []
        self.stop = threading.Event()
        self.kill_time = None
        from transformers import AutoTokenizer
        tokenizer = AutoTokenizer.from_pretrained(str(MODEL), trust_remote_code=True)
        self.tokenizer = tokenizer
        self.material = ('计算系统通过缓存减少重复计算，任务结束后需要释放占用的资源。' * 200)

    def emit(self, value):
        with self.lock:
            with (self.output / 'events.jsonl').open('a') as stream:
                stream.write(json.dumps(value, ensure_ascii=False) + '\n')
        print(json.dumps(value, ensure_ascii=False), flush=True)

    def post(self, role, body, rid, lane, timeout=350):
        started = time.time()
        request = urllib.request.Request(f'http://127.0.0.1:{PORTS[role]}/v1/completions',
            data=json.dumps(body).encode(), headers={'Content-Type': 'application/json', 'X-Request-Id': rid})
        result = {'role': role, 'request_id': rid, 'lane': lane, 'started': started}
        try:
            opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
            with opener.open(request, timeout=timeout) as response:
                result.update(code=response.status, body=json.loads(response.read()))
        except urllib.error.HTTPError as error:
            result.update(code=error.code, error_body=error.read().decode(errors='replace'))
        except Exception as error:
            result.update(error=repr(error))
        result.update(ended=time.time(), elapsed=time.time() - started)
        write(self.output / (rid + '-' + role + '.json'), result)
        with self.lock:
            self.responses.append(result)
        self.emit({key: result[key] for key in ('role', 'request_id', 'lane', 'started', 'ended', 'elapsed')} |
                  {'code': result.get('code'), 'error': result.get('error')})
        return result

    def prepare(self, role, lane):
        rid = f'{self.args.label}-{lane}-{uuid.uuid4()}'
        prompt = self.tokenizer.encode(rid + '\n' + self.material, add_special_tokens=False)[:1024]
        if len(prompt) != 1024:
            raise ValueError('实验提示词必须包含 1024 个 token')
        body = {'model': 'Qwen3.5-35B-A3B-FP8', 'prompt': prompt,
                'max_tokens': 1, 'temperature': 0, 'stream': False}
        result = self.post(role, body, rid, lane + '-prefill', timeout=60)
        params = result.get('body', {}).get('kv_transfer_params')
        if result.get('code') != 200 or not params:
            raise RuntimeError(f'{role} 未返回真实 KV 参数；{rid}')
        body.update(max_tokens=16, kv_transfer_params=params)
        write(self.output / (rid + '-metadata.json'), {'prefill_role': role,
              'request_id': rid, 'prompt_tokens': 1024, 'kv_transfer_params': params})
        return rid, body

    @staticmethod
    def model_success(result):
        return result.get('code') == 200 and bool(result.get('body', {}).get('choices'))

    def healthy_loop(self, decode):
        while not self.stop.is_set():
            try:
                rid, body = self.prepare('p1', 'healthy-' + decode)
                self.post(decode, body, rid, 'healthy-p1-' + decode)
            except Exception as error:
                self.emit({'phase': 'healthy_lane_error', 'decode': decode, 'error': repr(error), 'ts': time.time()})
            self.stop.wait(2)

    def direct_loop(self, decode):
        body = {'model': 'Qwen3.5-35B-A3B-FP8', 'prompt': '请简短说明缓存的作用。',
                'max_tokens': 8, 'temperature': 0, 'stream': False}
        while not self.stop.is_set():
            rid = self.args.label + '-direct-' + decode + '-' + str(uuid.uuid4())
            self.post(decode, body, rid, 'direct-' + decode)
            self.stop.wait(2)

    def snapshot(self, service_records):
        roles = {}
        for role, record in service_records.items():
            try:
                rows = descendants(record['pid'], record['start_ticks'])
                # 此环境未安装 setproctitle；用本轮日志中的 rank→PID 与当前进程树交叉验证。
                kind = 'TP'
                matches = re.findall(r'\(Worker_' + kind + r'(\d+)_EP\d+ pid=(\d+)\)',
                                     (self.root / 'logs' / (role + '.log')).read_text(errors='replace'))
                ranks = {int(pid): int(rank) for rank, pid in matches}
                for row in rows:
                    if row['pid'] in ranks:
                        row['worker_rank'] = ranks[row['pid']]
                        row['worker_kind'] = kind
                roles[role] = rows
            except (OSError, ValueError) as error:
                roles[role] = {'error': repr(error)}
        return roles

    def stacks(self, role, records):
        if not isinstance(records, list):
            return []
        output = []
        for row in records:
            if 'worker_rank' in row:
                try:
                    sampled = subprocess.run([str(BASE / 'venv/bin/py-spy'), 'dump',
                        '--pid', str(row['pid']), '--nonblocking', '--json'],
                        capture_output=True, text=True, timeout=5)
                    output.append({'identity': row, 'returncode': sampled.returncode,
                        'threads': json.loads(sampled.stdout) if sampled.returncode == 0 else [],
                        'stderr': sampled.stderr})
                except Exception as error:
                    output.append({'identity': row, 'error': repr(error)})
        return output

    def run(self):
        if not (self.root / 'READY').exists():
            raise RuntimeError('本轮四个模型服务尚未 READY')
        states = {role: health(port) for role, port in PORTS.items()}
        if any(value != 200 for value in states.values()):
            raise RuntimeError(f'四角色健康基线未成立：{states}')
        service_records = json.loads((self.root / 'services.json').read_text())
        write(self.output / 'baseline-processes.json', self.snapshot(service_records))
        for repeat in range(3):
            for prefill in ('p0', 'p1'):
                for decode in ('d0', 'd1'):
                    rid, body = self.prepare(prefill, f'baseline{repeat}-{decode}')
                    result = self.post(decode, body, rid, f'baseline-{prefill}-{decode}', 90)
                    if not self.model_success(result):
                        raise RuntimeError(f'正常 P→D 对照失败：{prefill}→{decode}, {rid}')
        pending = {decode: self.prepare('p0', 'fault-' + decode) for decode in ('d0', 'd1')}
        records = self.snapshot(service_records)['p0']
        candidates = [row for row in records if row.get('worker_rank') == self.args.rank]
        if len(candidates) != 1:
            raise RuntimeError(f'P0 TP{self.args.rank} 必须唯一，实际={candidates}')
        target = candidates[0]
        if target['uid'] != os.getuid():
            raise ValueError('只允许对本账号本次实验创建的 worker 注入故障')
        maps = {}
        for role, rows in self.snapshot(service_records).items():
            if isinstance(rows, list):
                for row in rows:
                    if 'worker_rank' in row:
                        maps[f'{role}-{row["pid"]}'] = [line for line in Path(f'/proc/{row["pid"]}/maps').read_text().splitlines()
                                                     if '_tpu_raiden_torch' in line or 'libtpu-logical-client' in line]
        write(self.output / 'loaded-maps.json', maps)
        fd = os.pidfd_open(target['pid'])
        try:
            current = identity(target['pid'])
            if current['start_ticks'] != target['start_ticks'] or current['state'] == 'Z':
                raise ValueError('注入前目标 generation 已改变或已退出')
            self.kill_time = time.time()
            write(self.output / 'injection.json', {'ts': self.kill_time, 'target': target, 'signal': 'SIGKILL'})
            signal.pidfd_send_signal(fd, signal.SIGKILL)
        finally:
            os.close(fd)
        self.emit({'phase': 'SIGKILL', 'ts': self.kill_time, 'target': target})
        if self.args.wait_closed:
            deadline = time.monotonic() + 30
            while True:
                try:
                    connection = socket.create_connection(('127.0.0.1', CONTROLLERS['p0']), timeout=1)
                except OSError as error:
                    write(self.output / 'controller-closed.json', {'ts': time.time(), 'error': repr(error)})
                    time.sleep(2)
                    break
                connection.close()
                if time.monotonic() >= deadline:
                    raise TimeoutError('P0 controller 未在 30 秒内关闭')
                time.sleep(0.2)
        pool = concurrent.futures.ThreadPoolExecutor(max_workers=6)
        futures = [pool.submit(self.post, decode, body, rid, 'fault-' + decode)
                   for decode, (rid, body) in pending.items()]
        futures += [pool.submit(self.healthy_loop, decode) for decode in ('d0', 'd1')]
        futures += [pool.submit(self.direct_loop, decode) for decode in ('d0', 'd1')]
        deadline = time.monotonic() + self.args.duration
        sample_index = 0
        try:
            while time.monotonic() < deadline:
                processes = self.snapshot(service_records)
                packet = {'ts': time.time(), 'elapsed_since_kill': time.time() - self.kill_time,
                    'health': {role: health(port) for role, port in PORTS.items()}, 'processes': processes}
                if sample_index % 3 == 0:
                    packet['stacks'] = {role: self.stacks(role, processes[role]) for role in ('d0', 'd1')}
                write(self.output / f'sample-{sample_index:03d}.json', packet)
                self.emit({'phase': 'sample', 'ts': packet['ts'], 'elapsed_since_kill': packet['elapsed_since_kill'], 'health': packet['health']})
                sample_index += 1
                time.sleep(5)
        finally:
            self.stop.set()
            pool.shutdown(wait=True)
        for future in futures:
            future.result()
        summaries = {}
        for lane in sorted({row['lane'] for row in self.responses}):
            rows = [row for row in self.responses if row['lane'] == lane]
            durations = sorted(row['elapsed'] for row in rows)
            def percentile(q):
                index = q * (len(durations) - 1)
                low = math.floor(index)
                high = math.ceil(index)
                return durations[low] + (durations[high] - durations[low]) * (index - low)
            summaries[lane] = {'count': len(rows), 'model_successes': sum(self.model_success(row) for row in rows),
                'codes': {str(code): sum(row.get('code') == code for row in rows) for code in set(row.get('code') for row in rows)},
                'avg': statistics.mean(durations), 'min': min(durations), 'max': max(durations),
                'stddev': statistics.pstdev(durations), 'p90': percentile(.9), 'p99': percentile(.99)}
        write(self.output / 'summary.json', {'kill_ts': self.kill_time, 'observation_seconds': self.args.duration,
            'target_rank': self.args.rank, 'wait_closed': self.args.wait_closed, 'lanes': summaries,
            'final_health': {role: health(port) for role, port in PORTS.items()},
            'final_processes': self.snapshot(service_records)})
        (self.output / 'DONE').write_text(str(time.time()))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--label', required=True)
    parser.add_argument('--rank', type=int, choices=(0, 1), default=0)
    parser.add_argument('--duration', type=int, default=360)
    parser.add_argument('--wait-closed', action='store_true')
    args = parser.parse_args()
    if args.duration < 330:
        raise ValueError('故障观察必须超过 300 秒 worker RPC 超时')
    case = Case(args)
    try:
        case.run()
    except BaseException as error:
        (case.output / 'FAILED').write_text(repr(error))
        raise
