"""Verify this bundle and recompute frozen kernel confirmation statistics."""
import collections
import hashlib
import json
from pathlib import Path
import statistics
import numpy as np


def main():
    root = Path(__file__).resolve().parent
    for name, expected in json.loads((root/'SHA256SUMS.json').read_text()).items():
        with (root/name).open('rb') as f:
            actual = hashlib.file_digest(f,'sha256').hexdigest()
        if actual != expected:
            raise ValueError(f'Hash mismatch: {name}')
    for case in json.loads((root/'cases.json').read_text()):
        records = json.loads((root/case['name']/'trace-summary.json').read_text())
        pairs = collections.defaultdict(dict)
        for record in records:
            events = json.loads((root/record['path']/'selected-events.json').read_text())
            groups = collections.defaultdict(list)
            expected_devices = set(record['devices'])
            for event in events:
                if (event['pid'],event['hlo_module_id'],event['hlo_name']) != (record['pid'],record['hlo_module_id'],record['hlo_name']):
                    raise ValueError('Unexpected program event')
                identity = event['host_execution_id']
                if identity is None:
                    if len(expected_devices)!=1 or event['run_id'] is None:
                        raise ValueError('Missing distributed correlation')
                    identity = (event['device'],event['queue_id'],event['run_id'])
                groups[str(identity)].append(event)
            samples = []
            if len(groups)!=50:
                raise ValueError('Incomplete repetitions')
            for parts in groups.values():
                if len(parts)!=len(expected_devices) or {e['device'] for e in parts}!=expected_devices:
                    raise ValueError('Incomplete or duplicate device partition')
                if any(e['start_unix_ps'] is None or e['duration_ps']<=0 for e in parts):
                    raise ValueError('Missing positive device duration')
                start = min(e['start_unix_ps'] for e in parts)
                stop = max(e['start_unix_ps']+e['duration_ps'] for e in parts)
                samples.append((start,(stop-start)/1e6))
            samples = [v for _,v in sorted(samples)]
            median = statistics.median(samples)
            if samples!=record['samples_us'] or median!=record['median_us']:
                raise ValueError('Reconstructed sample mismatch')
            if record['role'] in pairs[record['pair']]:
                raise ValueError('Duplicate role')
            pairs[record['pair']][record['role']]=median
        if set(pairs)!=set(range(10)) or any(set(p)!={'baseline','candidate'} for p in pairs.values()):
            raise ValueError('Incomplete independent pairs')
        ordered = [pairs[i] for i in range(10)]
        baseline = statistics.mean(p['baseline'] for p in ordered)
        candidate = statistics.mean(p['candidate'] for p in ordered)
        ratios = np.array([p['candidate']/p['baseline'] for p in ordered])
        bootstrap = np.random.default_rng(1729).choice(ratios,(10000,10),replace=True).mean(axis=1)
        ci = np.quantile(bootstrap,[.025,.975]).tolist()
        if not (np.isclose(baseline,case['baseline_us'],rtol=0,atol=1e-8) and np.isclose(candidate,case['candidate_us'],rtol=0,atol=1e-8) and np.allclose(ci,case['ratio_ci95'],rtol=0,atol=1e-12)):
            raise ValueError('Reported confirmation statistics mismatch')
        if not (candidate<.98*baseline and ci[1]<1):
            raise ValueError('Frozen acceptance gate failed')
        print(f"{case['benchmark']}: {baseline:.6f} -> {candidate:.6f} us; {100*(1-candidate/baseline):.4f}% reduction; CI95={ci}")
    print('All hashes, reconstructed samples and confirmation gates passed.')


if __name__ == '__main__':
    main()
