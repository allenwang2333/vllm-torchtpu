# GDN pooled prefill, medium

The captured 2,048-token pooled GDN operation improved from **155.297461 us
to 138.769539 us**, a **10.64% device-latency reduction**. The independent
ten-pair candidate/baseline ratio interval is
`[0.893452400056, 0.893708397324]`.

For the guarded single-sequence configuration, the kernel derives tile addresses,
sizes and first/last flags from four shared SMEM scalars. This replaces five
2,048-element metadata tables. The new provider fits the existing metadata and
pipeline interfaces; the numerical GDN computation remains unchanged.

All 26 timing blocks were independently recomputed. Both the integer state pool
and BF16 activation outputs are bit exact across all 13 canonical/scaled pairs.
Loaded source hashes match, the patch reconstructs the accepted tree, and its
commit carries the required DCO sign-off. All 17 additional sequence-boundary, carried-state, and valid decode fallback
cases match the baseline exactly, including empty and partial chunks and a
nonzero query offset. The original supplementary test included an invalid
decode case; its baseline failure and the caller-contract correction are retained
in [the diagnosis](../gdn-single-seq-extra-v1/diagnosis.json).

Phase 6 classified the computed metadata provider as a novel kernel-library
abstraction. It uses existing JAX/Pallas primitives and required no HiERevo core
change. No model speedup is claimed.

Accepted commit: `7ad8540aace3a097f071f9021b09e0fced1f6ef3`.

[Result and audits](gdn-pooled-prefill-medium.json),
[patch](gdn-pooled-prefill-medium.patch).

[Additional validation](../gdn-single-seq-extra-v2/candidate/validation.json).
