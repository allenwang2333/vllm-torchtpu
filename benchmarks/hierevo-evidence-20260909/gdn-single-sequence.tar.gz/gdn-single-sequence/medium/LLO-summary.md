# Static LLO comparison

Counts describe static emitted instruction sites, including overlays; they are not dynamic operation counts or cycle estimates.

| Opcode | Baseline | Candidate |
| --- | ---: | ---: |
| `vsyncpa.u1` | 94 | 54 |
| `vst.8x128` | 13515 | 13499 |
| `vwait.ge` | 71 | 56 |
| `vtrace` | 78 | 64 |
| `vsyncadd.s32` | 135 | 122 |
| `vld.8x128` | 13862 | 13850 |
| `vsel.8x128` | 1333 | 1322 |
| `vlt.8x128.s32` | 29 | 19 |
| `vmov.8x128` | 32 | 25 |
| `vlaneseq.8x128.u32` | 18 | 12 |
| `vadd.8x128.s32` | 29 | 23 |
| `vm0` | 131 | 125 |

The complete numbered LLO dumps and compiled HLO are in `compiled/baseline` and `compiled/candidate`.

## Representative emitted records

### baseline

```text
25 : {_ = sfence;  _ = vwait.ge [sflag:$511], s4}
245 : {[vmem:$0x3ffe0] = vst.8x128 v62}
246 : {s3 = simm.u32 $50;  s1 = sld [smem:$0x3b];  v59 = vimm.8x128.s32 $0;  v62 = vlaneseq.8x128.u32;  [vmem:$0x3fff8] = vst.8x128 v59}
247 : {[vmem:$0x3fff0] = vst.8x128 v60}
248 : {p0 = slt.s32 s1, $95;  s2 = simm.u32 $0;  v59 = vsel.8x128 vm0, $0x1, v59;  v63 = vand.8x128.u32 $0x380, v62;  [vmem:$0x3ffd8] = vst.8x128 v63}
249 : {p0 = slt.s32 s1, $85;  s2 = simm.u32 @p0 $1;  vm0 = veq.8x128.s32 v63, $0;  [vmem:$0x3ffe8] = vst.8x128 v61}
259 : {p0 = slt.s32 s1, $15;  s2 = simm.u32 @p0 $32;  [vmem:$0x3ffd0] = vst.8x128 v0}
260 : {s2 = simm.u32 @p0 $72;  s3 = simm.u32 @p0 $6;  [vmem:$0x3ffc8] = vst.8x128 v1}
```

### candidate

```text
25 : {_ = sfence;  _ = vwait.ge [sflag:$511], s4}
245 : {[vmem:$0x3ffe0] = vst.8x128 v62}
246 : {s3 = simm.u32 $50;  s1 = sld [smem:$0x3b];  v59 = vimm.8x128.s32 $0;  v62 = vlaneseq.8x128.u32;  [vmem:$0x3fff8] = vst.8x128 v59}
247 : {[vmem:$0x3fff0] = vst.8x128 v60}
248 : {p0 = slt.s32 s1, $95;  s2 = simm.u32 $0;  v59 = vsel.8x128 vm0, $0x1, v59;  v63 = vand.8x128.u32 $0x380, v62;  [vmem:$0x3ffd8] = vst.8x128 v63}
249 : {p0 = slt.s32 s1, $85;  s2 = simm.u32 @p0 $1;  vm0 = veq.8x128.s32 v63, $0;  [vmem:$0x3ffe8] = vst.8x128 v61}
259 : {p0 = slt.s32 s1, $15;  s2 = simm.u32 @p0 $32;  [vmem:$0x3ffd0] = vst.8x128 v0}
260 : {s2 = simm.u32 @p0 $72;  s3 = simm.u32 @p0 $6;  [vmem:$0x3ffc8] = vst.8x128 v1}
```

