# HiERevo accepted-kernel evidence

These measurements belong to the frozen captured source and runtime revisions,
not to an unmeasured port onto a later upstream revision. Each shape contains:

- all 20 raw XPlane confirmation traces and original execution records;
- decoded selected program events, exact device partitions and 50 samples/block;
- complete numbered baseline/candidate LLO, compiled HLO, and one representative
  executable per role (confirmation pair 00);
- original result, Phase 5/6 records, available supplemental audit receipts,
  runtime/geometry metadata, and static LLO comparisons.

The packaging audit re-read every raw trace, verified its SHA256 and executable
identity, reconstructed its exact device samples, and checked its block median.
It also verified every confirmation block's LLO against the sealed role hash.
`source-path-map.json` maps original local artifact paths to the bundled files.
Original JSON and reports retain historical paths and are byte-preserved.
Raw output tensors and every repeated executable are not included in this bundle.

Run `python verify_evidence.py` with NumPy installed to verify all bundled hashes,
reconstruct the 50 samples per block from selected events, and independently
recompute the ten-pair means, bootstrap confidence interval and acceptance gate.
Raw `.xplane.pb` files can also be opened with the XProf/TensorBoard profile tools.
The derived JSON events are convenient for inspection; the original XPlane files
remain the primary trace evidence. No full-model gain is claimed.
